/**
 *Sabro - 14/06/2018 
 */

function mensagem(num) {
	var nome = $(".nome"+num).text();
	var sobrenome = $(".sobrenome"+num).text();
	var apelido = $(".apelido"+num).text();
	var sexo = $(".sexo"+num).text();
	$(".nome"+num).html("<input type='text' id='inpnome"+num+"' value='"+nome+"'>");
	$(".sobrenome"+num).html("<input type='text' id='inpsobrenome"+num+"' value='"+sobrenome+"'>");
	$(".apelido"+num).html("<input type='text' id='inpapelido"+num+"' value='"+apelido+"'>");
	$(".sexo"+num).html("<input type='text' id='inpsexo"+num+"' value='"+sexo+"'>");
	$(".alt"+num).html("<a href='#' onclick='alterar("+num+")'>&radic;</a>");
}
function alterar(num){
	var nome = document.getElementById("inpnome"+num).value;
	var sobrenome = document.getElementById("inpsobrenome"+num).value;
	var apelido = document.getElementById("inpapelido"+num).value;
	var sexo = document.getElementById("inpsexo"+num).value;
	if(nome=="" || nome==null) alert("Digite o nome!");
	else if(sobrenome=="" || sobrenome==null) alert("Digite o sobrenome!");
	else if(apelido=="" || apelido==null) alert("Digite o apelido!");
	else if(sexo=="" || sexo==null) alert("Digite o sexo!");
	else window.location.href = "Cliente?funcao=alterar&num="+num+"&first-name="+nome+"&last-name="+sobrenome+"&middle-name="+apelido+"&gender="+sexo;
	return false;
}