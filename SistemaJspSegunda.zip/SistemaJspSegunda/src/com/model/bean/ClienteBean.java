package com.model.bean;

import java.util.Calendar;

public class ClienteBean {
    int id;
    String nome;
    String sobrenome;
    String apelido;
    String sexo;
	Calendar nascimento;

    public ClienteBean(int id, String nome, String sobrenome, String apelido, String sexo) {
    	this.id = id;
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.apelido = apelido;
        this.sexo = sexo;
    }
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public String getApelido() {
		return apelido;
	}
	public void setApelido(String apelido) {
		this.apelido = apelido;
	}
	public Calendar getNascimento() {
		return nascimento;
	}
	public void setNascimento(Calendar data) {
		this.nascimento = data;
	}
    public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
}