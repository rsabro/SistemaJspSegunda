package com.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.model.bean.ClienteBean;
import com.model.factory.ConnectionFactory;

public class ClienteDAO {

	private final Connection con;

	public ClienteDAO() throws SQLException {
		this.con = new ConnectionFactory().getConnection();
	}

    public List<ClienteBean> buscarTodos() {
        try {
        	List<ClienteBean> listCliente = new ArrayList<ClienteBean>();
            String sql = "select * from cliente";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
//            	Calendar data = Calendar.getInstance();
//            	data.setTime(rs.getDate("data"));
            	ClienteBean clientes = new ClienteBean(rs.getInt("id"),rs.getString("nome"),rs.getString("sobrenome"),rs.getString("apelido"),rs.getString("sexo"));
                listCliente.add(clientes);
            }
            rs.close();
            ps.close();
            con.close();
            return listCliente;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

	public void excluir(int id){
		String sql = "delete from cliente" +
					" where id = " + id;
		PreparedStatement stmt;
		try{
			stmt = con.prepareStatement(sql);
			stmt.execute();
			stmt.close();
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
	}

	public void cadastrar(ClienteBean cliente) {
		String sql = "insert into cliente" +
				" (nome, sobrenome, apelido, data, sexo)" +
				" values (?,?,?,?,?);";
		PreparedStatement stmt;
		try{
			stmt = con.prepareStatement(sql);
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getSobrenome());
			stmt.setString(3, cliente.getApelido());
			Calendar data = Calendar.getInstance();
			stmt.setDate(4, new java.sql.Date(data.getTimeInMillis()));
			stmt.setString(5, cliente.getSexo());
			stmt.execute();
			stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
