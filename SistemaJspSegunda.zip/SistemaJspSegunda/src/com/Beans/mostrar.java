/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Beans;

/**
 *
 * @author will
 */
public class mostrar {
	public String show() {
        String sql = "SELECT * FROM `imagem` WHERE 1";
        return sql;
    }
}