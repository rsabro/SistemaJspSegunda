package com.servlets;

import java.sql.SQLException;
import java.util.List;
import com.model.bean.ClienteBean;
import com.model.dao.ClienteDAO;

public class testeCliente {

	public static void main(String[] args) throws SQLException {
		ClienteDAO dao = new ClienteDAO();
		List<ClienteBean> clientes = dao.buscarTodos();
		for(ClienteBean ClienteBean : clientes){
			System.out.println(ClienteBean.getNome());
		}
	}

}