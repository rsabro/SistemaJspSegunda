package com.servlets;

import java.sql.SQLException;

import com.model.factory.ConnectionFactory;

public class testeConnection {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		ConnectionFactory conn = new ConnectionFactory();
		System.out.println(conn.getConnection());
//		Calendar data = Calendar.getInstance();
//		System.out.println(data.getTime());
	}

}